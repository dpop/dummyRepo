<?php

include_once './vendor/autoload.php';

include_once './work.php';
?>